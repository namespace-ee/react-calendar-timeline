import React from 'react'
import ReactDOM from 'react-dom'
import App from './app'

import './index.html'

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
