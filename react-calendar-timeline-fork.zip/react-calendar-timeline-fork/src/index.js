import Timeline from './lib/Timeline'

export default Timeline
